import React, { useEffect, useMemo, useState } from 'react';
import { marketApi } from '../../../api';

function TickerBar({ onCoinClick }) {
    const [coins, setCoins] = useState([]);
    const [view, setView] = useState('gainers');
    const [isHovered, setIsHovered] = useState(false);
    const [isLoading, setIsLoading] = useState(true);
    const [hasError, setHasError] = useState(false);

    useEffect(() => {
        let cancelled = false;

        const fetchTicker = async () => {
            try {
                const res = await marketApi.getTicker24h();
                const items = Array.isArray(res?.data) ? res.data : [];

                const mapped = items
                    .filter((item) => item?.symbol && item?.price != null && item?.change != null)
                    .map((item) => ({
                        symbol: item.symbol.replace('USDT', ''),
                        fullSymbol: item.symbol,
                        price: Number(item.price),
                        change: Number(item.change),
                    }))
                    .filter((item) => Number.isFinite(item.price) && Number.isFinite(item.change));

                if (!cancelled) {
                    if (mapped.length > 0) {
                        setCoins(mapped);
                    }
                    setHasError(mapped.length === 0);
                    setIsLoading(false);
                }
            } catch (error) {
                console.error('Ticker fetch error:', error);
                if (!cancelled) {
                    setHasError(true);
                    setIsLoading(false);
                }
            }
        };

        fetchTicker();
        const interval = setInterval(fetchTicker, 15000);

        return () => {
            cancelled = true;
            clearInterval(interval);
        };
    }, []);

    const activeCoins = useMemo(() => {
        const sorted = [...coins].sort((a, b) =>
            view === 'gainers' ? b.change - a.change : a.change - b.change
        );
        return sorted.slice(0, 10);
    }, [coins, view]);

    const renderPlaceholder = (text) => (
        <div
            style={{
                width: '100%',
                height: '42px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                gap: '12px',
                padding: '0 12px',
                background: 'rgba(15,15,25,0.92)',
                borderBottom: '1px solid rgba(255,255,255,0.06)',
                color: '#aaa',
                fontSize: '12px',
                zIndex: 20
            }}
        >
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <button
                    onClick={() => setView('gainers')}
                    style={{
                        background: view === 'gainers' ? 'rgba(88, 214, 141, 0.15)' : 'transparent',
                        color: view === 'gainers' ? '#58d68d' : '#aaa',
                        border: '1px solid rgba(255,255,255,0.06)',
                        borderRadius: '8px',
                        padding: '6px 10px',
                        cursor: 'pointer',
                        fontWeight: 700
                    }}
                >
                    Gainers
                </button>
                <button
                    onClick={() => setView('losers')}
                    style={{
                        background: view === 'losers' ? 'rgba(255, 122, 122, 0.15)' : 'transparent',
                        color: view === 'losers' ? '#ff7a7a' : '#aaa',
                        border: '1px solid rgba(255,255,255,0.06)',
                        borderRadius: '8px',
                        padding: '6px 10px',
                        cursor: 'pointer',
                        fontWeight: 700
                    }}
                >
                    Losers
                </button>
            </div>
            <span>{text}</span>
        </div>
    );

    if (isLoading && !activeCoins.length) {
        return renderPlaceholder('Ticker məlumatı yüklənir...');
    }

    if (!activeCoins.length) {
        return renderPlaceholder('Ticker məlumatı hazır deyil.');
    }

    return (
        <div
            style={{
                width: '100%',
                height: '42px',
                display: 'flex',
                alignItems: 'center',
                background: 'rgba(15,15,25,0.92)',
                borderBottom: '1px solid rgba(255,255,255,0.06)',
                overflow: 'hidden',
                position: 'relative',
                zIndex: 20
            }}
        >
            <div
                style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    padding: '0 12px',
                    borderRight: '1px solid rgba(255,255,255,0.05)',
                    flexShrink: 0
                }}
            >
                <button
                    onClick={() => setView('gainers')}
                    style={{
                        background: view === 'gainers' ? 'rgba(88, 214, 141, 0.15)' : 'transparent',
                        color: view === 'gainers' ? '#58d68d' : '#aaa',
                        border: '1px solid rgba(255,255,255,0.06)',
                        borderRadius: '8px',
                        padding: '6px 10px',
                        cursor: 'pointer',
                        fontWeight: 700
                    }}
                >
                    Gainers
                </button>

                <button
                    onClick={() => setView('losers')}
                    style={{
                        background: view === 'losers' ? 'rgba(255, 122, 122, 0.15)' : 'transparent',
                        color: view === 'losers' ? '#ff7a7a' : '#aaa',
                        border: '1px solid rgba(255,255,255,0.06)',
                        borderRadius: '8px',
                        padding: '6px 10px',
                        cursor: 'pointer',
                        fontWeight: 700
                    }}
                >
                    Losers
                </button>
            </div>

            <div
                style={{ overflow: 'hidden', flex: 1, display: 'flex', height: '100%', alignItems: 'center' }}
                onMouseEnter={() => setIsHovered(true)}
                onMouseLeave={() => setIsHovered(false)}
            >
                <div
                    key={view}
                    style={{
                        display: 'inline-flex',
                        animation: `ticker-scroll 60s linear infinite ${isHovered ? 'paused' : 'running'}`,
                        whiteSpace: 'nowrap'
                    }}
                >
                    {[...activeCoins, ...activeCoins].map((coin, idx) => {
                        const isPositive = coin.change >= 0;
                        const colorCode = isPositive ? '#58d68d' : '#ff7a7a';
                        const bgColor = isPositive ? 'rgba(88, 214, 141, 0.1)' : 'rgba(255, 122, 122, 0.1)';

                        return (
                            <div
                                key={`${coin.fullSymbol}-${idx}`}
                                onClick={() => onCoinClick && onCoinClick(coin.fullSymbol)}
                                style={{
                                    display: 'inline-flex',
                                    alignItems: 'center',
                                    gap: '10px',
                                    padding: '0 24px',
                                    height: '42px',
                                    cursor: onCoinClick ? 'pointer' : 'default',
                                    borderRight: '1px solid rgba(255,255,255,0.03)',
                                    opacity: hasError ? 0.85 : 1
                                }}
                            >
                                <span style={{ fontSize: '12px', fontWeight: 800, color: 'rgba(255,255,255,0.8)' }}>
                                    {coin.symbol}
                                </span>

                                <span style={{ fontSize: '13px', fontWeight: 700, color: '#fff' }}>
                                    ${coin.price.toLocaleString(undefined, {
                                    minimumFractionDigits: coin.price < 1 ? 4 : 2,
                                    maximumFractionDigits: coin.price < 1 ? 4 : 2
                                })}
                                </span>

                                <span
                                    style={{
                                        fontSize: '11px',
                                        fontWeight: 800,
                                        color: colorCode,
                                        background: bgColor,
                                        padding: '3px 8px',
                                        borderRadius: '6px'
                                    }}
                                >
                                    {isPositive ? '+' : ''}
                                    {coin.change.toFixed(2)}%
                                </span>
                            </div>
                        );
                    })}
                </div>
            </div>

            <style>{`
                @keyframes ticker-scroll {
                    0% { transform: translateX(0); }
                    100% { transform: translateX(-50%); }
                }
            `}</style>
        </div>
    );
}

export default TickerBar;